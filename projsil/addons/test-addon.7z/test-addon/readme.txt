 If you read this, that means that addon patching works.
