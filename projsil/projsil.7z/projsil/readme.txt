Team Fortress 2 hit- and killsound by mitchellshephardsuperfan for ProjSil 51.

Default TF2 hit- and killsound ported to ProjSilDM.

Credits: Valve Software for everything TF2.
Dependencies: none
Conflits with the following addons: none.
License: CC BY-NC-ND 4.0

